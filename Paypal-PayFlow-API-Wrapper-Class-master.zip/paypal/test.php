<!DOCTYPE html>
<head>
  <!-- PAYPAL ---------->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <script
  src="https://www.paypal.com/sdk/js?client-id=SB_CLIENT_ID">
  </script>
    <!--- END PAYPAL -------->
  <meta http-equiv="X-UA-Compatible" content="IE=9" />
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="yandex-verification" content="45a102c9df353a2a" />

  <title>Realty Connection - Real  Estate  Careers | Compare Real  Estate  Companies in Colrain Massachusetts</title>
  <meta name="keywords" content="Real Estate Careers, Real Estate Jobs, Real  Estate  Job Placement, Compare Real  Estate  Companies, Compare Real  Estate  Firms, Real  Estate  Compensation Plans, Real  Estate  Licensing, Real  Estate  Agent Jobs, Best Real  Estate  Brokerages, Work  in Real  Estate , Real  Estate  Commission, Real  Estate  Business Models">
  <meta name="description" content="Find the Right Real Estate Company. It's FREE and Anonymous. Compare Company Business Models in Colrain Massachusetts or pick your location from the United States.">
  <link href="https://www.realtyconnection.com/css/user_style.css" rel="stylesheet" type="text/css">
  
  <style>
     .upgrade_package_form .fld_cont select {
      display: inline-block;
      padding: 14px 12px;
      font-size: 15px;
      box-shadow: 0px 0px 10px #ccc inset;
      width: 350px;
      border-radius: 4px;
      box-sizing: border-box;
    }
    .upgrade_package_form .fld_cont .ininputs_pop{ display:inline-block; width: 350px;}
    .upgrade_package_form .fld_cont .regInptTxt, .upgrade_package_form .fld_cont .regInptSel select{ height:auto; background:#fff !important;}
    .regInptSel{ height:auto; width:350px !important}
    .upgrade_package_form .fld_cont label{ vertical-align:top; padding: 15px 20px 0 0;}
    .regInptInner{ display:inline-block;}
    .regInptSel span{  display:inline-block;  vertical-align:top; padding: 15px 0 0 5px;}
    h1.pageHeadr{     font-family: inherit;
    margin-bottom: 0px;
    padding: 10px 15px;
    border-bottom: 1px solid #ccc;
    float: left;
    width: 100%;
    background: #1783bd;
    box-sizing: border-box;
    color: #fff;}
  
  .upgrade_package_cont{ box-shadow:none;border-radius:0px; border:1px solid #ccc; border-top:none;}
  </style>
</head>
<!-- START HEADER -->
<header>
  <div class="headrTopBar">
    <div class="container">
      <!-- <div class="hphone"><img src="https://www.realtyconnection.com/images/hphone.png" alt="">1-800-RCA-5198</div> -->
        <div class="deLocation"><a href="javascript:void(null)" onclick="launchApplication('https://www.realtyconnection.com/imchat?r=||&amp;s=||&amp;onOff=21212', 'chat');"></a>
        </div>
    </div>
    <div class="clear"></div>
  </div>
  <article>
    <div class="container header">
      <div class="logoWrap"><a href="https://www.realtyconnection.com/" title="Realty Connection"><img src="https://www.realtyconnection.com/images/user_images/logo.png" alt="Realty Connection" class="w253px"></a> </div>
    </div>
  </article>
</header>
<div class="wrapper">
<!-- START CONTENT -->
    <div class="contentWrap">
    <div class="left"><img src="https://www.realtyconnection.com/images/user_images/content_top.png" width="978" height="10" alt="" class="left"></div>
    <div class="contMid">   
      <h1 class="pageHeadr left">Pricing</h1>   
        <div class="" id="upgrade_package_modal" style="">
      <div class="upgrade_package_cont">
         <div class="upgrade_pack_head"><i class="fa fa-check">&nbsp</i>Please fill the below information.34534</div>
         <form action="PaymentController.php" method="POST">
               <div class="upgrade_package_form" id="">
                <div class="fld_cont">
                  <label>*First Name</label>
                  <input type="text" name="first_name" id="first_name" placeholder="Enter your first name" required>
                </div>
                <div class="fld_cont">
                  <label>*Last Name</label>
                  <input type="text" name="last_name" id="last_name" placeholder="Enter your last name" required>
                </div>
                <div class="fld_cont">
                  <label>*Contact Name</label>
                  <input type="text" name="contact_name" id="con_name" placeholder="Enter your company name" required>
                </div>
                <div class="fld_cont">
                  <label>*Email</label>
                  <input type="text" name="email" id="con_email" placeholder="Enter your email" required>
                </div>
                <div class="fld_cont">
                  <label>*Phone</label>
                  <input type="text" name="phone" id="con_phone" placeholder="Enter your phone number" required>
                </div>
                <div class="fld_cont">
                  <label>*Card Type</label>
                  <select name="CreditCardType" class="form-control required" id="pay_select_card" required>
                                <option value="" selected="selected">Select Card Type</option>
                                <option value="Visa">Visa</option>
                                <option value="MasterCard">MasterCard</option>
                                <option value="Amex">Amex</option>
                                <option value="Discover">Discover</option>
                            </select>
                </div>
                <div class="fld_cont">
                  <label>*Card Number</label>
                  <input type="text" name="card_number" id="pay_card_no" placeholder="Enter your card number" required>
                </div>
                <div class="fld_cont">
                  <label>*Name on Card</label>
                  <input type="text" name="card_name" id="card_name" placeholder="Enter your name on card" required>
                </div>
                <div class="fld_cont">
                  <label>*CVV</label>
                  <input type="password" name="pay_card_cvv" maxlength="4" id="pay_card_cvv" class="form-control" placeholder="Enter CVV" required>
                </div>
                <div class="fld_cont">
                  <label>*Expiration</label>
                  <div class="ininputs_pop">
                                <div class="regInptSel">
                                    <div class="regInptInner">
                                        <select class="form-control" name="CardExpDateMonth" style="width:150px;" id="pay_card_month" required>
                                            <option value="" selected="selected">Select Month</option>
                                            <?php 
                                            for($m = 1; $m <= 12; $m++) 
                                            { 
                                              $month = $m <=9 ? '0'.$m : $m;
                                            ?>
                                              <option value="<?php echo $month; ?>"><?php echo $month; ?></option>
                                          <?php } ?>
                                        </select>
                                        <div class="LV_validation_message LV_invalid" id="pay_card_month_msg" style="display:none">Please fill out this field</div>
                                    </div>
                                    <div class="regInptInner">
                                        <select name="CardExpDateYear" class="form-control" style="width:130px;margin-left:4px;" id="pay_card_year" required>
                                            <option value="" selected="selected">Select Year</option>
                                            <?php for($y = 14; $y <= 37; $y++){ ?>
                                            <option value="<?php echo $y; ?>"><?php echo $y; ?></option>
                                          <?php } ?>
                                        </select>
                                        <div class="LV_validation_message LV_invalid" id="pay_card_year_msg" style="display:none">Please fill out this field</div>
                                    </div>
                                    <span>(MM YY) </span>
                                </div>
                            </div>
                </div>
                <div class="fld_cont">
                  <label>&nbsp;</label>
                  <button type="submit" title="Submit">Submit</button>
                  <button type="button" title="Submit" id="cancel_request">Cancel</button>
                </div>
               </div>
         </form>
      </div>
    </div>
      <!-- / End Pricing -->
    <!--</form>-->
    <!-- End Pricing -->
    <div class="left"><img src="https://www.realtyconnection.com/images/user_images/content_btm.png" width="978" height="10" alt=""></div>
    <div class="clear"></div>
   </div>
  <!-- END CONTENT -->
  </div>
  <div class="clear"></div>
</div>
<!-- START FOOTER -->
<footer class="footerWrap">
  <article class="container">
    <div class="connect">
      <div class="left_contact">
        <h1>Connect With Us</h1>
        <div class="social"> <a href="https://twitter.com/info_realty" target="_blank" onclick="return redirectCheck(this);"> <img src="https://www.realtyconnection.com/images/user_images/icon_twitter.png" alt="Twitter" width="32" height="32"></a> <a href="https://www.facebook.com/pages/Realty-Connection/308122932540808?fref=ts" onclick="return redirectCheck(this);" target="_blank"> <img src="https://www.realtyconnection.com/images/user_images/icon_fb.png" alt="Facebook" width="32" height="32"></a> <a href="http://www.youtube.com/user/RealtyConnection183" target="_blank" onclick="return redirectCheck(this);"> <img src="https://www.realtyconnection.com/images/user_images/youtube.png" alt="Youtube" width="32" height="32"></a> <a href="http://www.linkedin.com/company/2887803?trk=tyah" target="_blank" onclick="return redirectCheck(this);"> <img src="https://www.realtyconnection.com/images/user_images/linkedin-icon.png" alt="Youtube" width="32" height="32"></a> </div>
       <div class="siteseal"> <span id="siteseal"><script async="" type="text/javascript" src="https://seal.godaddy.com/getSeal?sealID=7c15cHW9dljlkSDXXPf7g6gYI2r8TmWcFf7jZ7Tj9v6AYysFtzWeTMUCNu2D"></script><img style="cursor:pointer;cursor:hand" src="https://seal.godaddy.com/images/3/en/siteseal_gd_3_h_l_m.gif" onclick="verifySeal();" alt="SSL site seal - click to verify"></span>
 </div>
      </div>
    
        
          <div class="left_ppartner">
        <div class="left">Proud Partner of<br>
                    <img src="https://www.realtyconnection.com/images/user_images/kalpan_logo.png" style="padding-top:5px">
                  </div>
      </div>
    </div>
    <div class="left_aboutlinks">
      <div class="section left quickLink">
        <div class="left margin_right">
          <ul>
            <li><a href="https://www.realtyconnection.com/about-realty-connection" onclick="return redirectCheck(this);">About us</a></li>
            <!--<li><a href="https://www.realtyconnection.com/realty-connection-partners" onClick="return redirectCheck(this);">Our Partners</a></li>-->
            <li><a href="https://www.realtyconnection.com/sitemap" onclick="return redirectCheck(this);">Sitemap </a></li>
            <li><a href="https://www.realtyconnection.com/contactus" onclick="return redirectCheck(this);">Contact us</a></li>
            <li><a href="https://www.realtyconnection.com/privacypolicy" onclick="return redirectCheck(this);">Privacy Policy</a></li>
            <li><a href="https://www.realtyconnection.com/faq" onclick="return redirectCheck(this);">FAQ</a></li>
            <li><a href="https://www.realtyconnection.com/disclaimer" onclick="return redirectCheck(this);">Disclaimer</a></li>
          </ul>
        </div>
        <div class="left">
          <ul>
            <!--<li><a href="https://www.realtyconnection.com/workrealtyconnection" onClick="return redirectCheck(this);">Work at Realty Connection</a></li>
            <li><a href="https://www.realtyconnection.com/market-to-real-estate-agents" onClick="return redirectCheck(this);">Join Our Resource Directory</a></li>-->
            <li><a href="https://www.realtyconnection.com/recruit-real-estate-agents" onclick="return redirectCheck(this);">List Your firm </a></li>
            <li><a href="https://www.realtyconnection.com/strategic_partner_association" onclick="return redirectCheck(this);">Partner with Us </a></li>
            <!---<li><a href="https://www.realtyconnection.com/real-estate-agent-advertising" onClick="return redirectCheck(this);">Place Banner Ads</a></li>
            <li><a href="https://www.realtyconnection.com/paymyfees" onClick="return redirectCheck(this);"> Agent Contest </a></li>   --->
          </ul>
        </div>
      </div>

      <!--Google Voice Call Widget-->
      <div class="section right" style="display:none">
        <h1>News Letter Signup</h1>
        <form action="https://www.realtyconnection.com/user/newsletter/" method="post" name="newletterform" id="newletterform">
                    <div class="nlFrmRow">
            <label>Name:</label>
            <input type="text" name="uname" id="uname">
          </div>
          <span class="status"></span>
          <div class="nlFrmRow">
            <label>E-mail:</label>
            <input type="text" name="emailid" id="emailid">
          </div>
          <span class="status"></span>
          <div class="nlFrmRow"> <span class="right">
            <input type="image" name="sub_newsl" id="sub_newsl" src="https://www.realtyconnection.com/images/user_images/btn_go-arrow.png" width="41" height="31" alt="Go">
            </span> </div>
        </form>
      </div>
      <div class="clear pTop30"></div>
    </div>
    <div class="footerBar">
      <p>© 2014 Realty Connection.<br>
        All Rights Reserved.</p>
    </div>
    <div class="clear"></div>
  </article>
</footer>
<!-- END FOOTER --> 