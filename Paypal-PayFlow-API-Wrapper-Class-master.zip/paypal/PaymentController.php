<?php

require_once('Class.PayFlow.php');
// recurring_payment();
one_time_payment();

function recurring_payment()
{
	$first_name 		=  $_POST['first_name'];
	$last_name 			=  $_POST['last_name'];
	$contact_name 		=  $_POST['contact_name'];
	$email 				=  $_POST['email'];
	$phone 				=  $_POST['phone'];
	$CreditCardType 	=  $_POST['CreditCardType'];
	$card_number 		=  $_POST['card_number'];
	$card_name 			=  $_POST['card_name'];
	$pay_card_cvv 		=  $_POST['pay_card_cvv'];
	$CardExpDateMonth 	=  $_POST['CardExpDateMonth'];
	$CardExpDateYear 	=  $_POST['CardExpDateYear'];

	// Recurring Transaction
	$PayFlow = new PayFlow('realtyconnection13', 'PayPal', 'SriKrishna', 'RCAdeveloper13617', 'recurring');

	$PayFlow->setEnvironment('test');                           // test or live
	$PayFlow->setTransactionType('R');                          // S = Sale transaction, R = Recurring, C = Credit, A = Authorization, D = Delayed Capture, V = Void, F = Voice Authorization, I = Inquiry, N = Duplicate transaction
	$PayFlow->setPaymentMethod('C');                            // A = Automated clearinghouse, C = Credit card, D = Pinless debit, K = Telecheck, P = PayPal.
	$PayFlow->setPaymentCurrency('USD');                        // 'USD', 'EUR', 'GBP', 'CAD', 'JPY', 'AUD'.

	// Only used for recurring transactions
	$PayFlow->setProfileAction('A');
	$PayFlow->setProfileName($first_name.' '.$last_name);
	$PayFlow->setProfileStartDate(date('mdY', strtotime("+1 month")));
	$PayFlow->setProfilePayPeriod('MONT');
	$PayFlow->setProfileTerm(0);

	$PayFlow->setAmount('99.00', FALSE);
	$PayFlow->setCCNumber($card_number);
	$PayFlow->setCVV($pay_card_cvv);
	$PayFlow->setExpiration($CardExpDateMonth.$CardExpDateYear);
	$PayFlow->setCreditCardName($card_name);

	$PayFlow->setCustomerFirstName($first_name);
	$PayFlow->setCustomerLastName($last_name);
	$PayFlow->setCustomerAddress('');
	$PayFlow->setCustomerCity('');
	$PayFlow->setCustomerState('');
	$PayFlow->setCustomerZip('');
	$PayFlow->setCustomerCountry('');
	$PayFlow->setCustomerPhone($phone);
	$PayFlow->setCustomerEmail($email);
	$PayFlow->setPaymentComment('this is for test');

	if($PayFlow->processTransaction()):
	  echo('Transaction Processed Successfully!');
	else:
	  echo('Transaction could not be processed at this time.');
	endif;
	 
	echo('<h2>Name Value Pair String:</h2>');
	echo('<pre>');
	print_r($PayFlow->debugNVP('array'));
	echo('</pre>');
	 
	echo('<h2>Response From Paypal:</h2>');
	echo('<pre>');
	print_r($PayFlow->getResponse());
	echo('</pre>');
	 
	unset($PayFlow);
}

function one_time_payment()
{
	$first_name 		=  $_POST['first_name'];
	$last_name 			=  $_POST['last_name'];
	$contact_name 		=  $_POST['contact_name'];
	$email 				=  $_POST['email'];
	$phone 				=  $_POST['phone'];
	$CreditCardType 	=  $_POST['CreditCardType'];
	$card_number 		=  $_POST['card_number'];
	$card_name 			=  $_POST['card_name'];
	$pay_card_cvv 		=  $_POST['pay_card_cvv'];
	$CardExpDateMonth 	=  $_POST['CardExpDateMonth'];
	$CardExpDateYear 	=  $_POST['CardExpDateYear'];

	// Single Transaction
	$PayFlow = new PayFlow('realtyconnection13', 'PayPal', 'SriKrishna', 'RCAdeveloper13617', 'single');

	$PayFlow->setEnvironment('test');                           // test or live
	$PayFlow->setTransactionType('S');                          // S = Sale transaction, R = Recurring, C = Credit, A = Authorization, D = Delayed Capture, V = Void, F = Voice Authorization, I = Inquiry, N = Duplicate transaction
	$PayFlow->setPaymentMethod('C');                            // A = Automated clearinghouse, C = Credit card, D = Pinless debit, K = Telecheck, P = PayPal.
	$PayFlow->setPaymentCurrency('USD');                        // 'USD', 'EUR', 'GBP', 'CAD', 'JPY', 'AUD'.

	$PayFlow->setAmount('199.00', FALSE);
	$PayFlow->setCCNumber($card_number);
	$PayFlow->setCVV($pay_card_cvv);
	$PayFlow->setExpiration($CardExpDateMonth.$CardExpDateYear);
	$PayFlow->setCreditCardName($card_name);

	$PayFlow->setCustomerFirstName($first_name);
	$PayFlow->setCustomerLastName($last_name);
	$PayFlow->setCustomerAddress('');
	$PayFlow->setCustomerCity('');
	$PayFlow->setCustomerCity('');
	$PayFlow->setCustomerState('');
	$PayFlow->setCustomerZip('');
	$PayFlow->setCustomerCountry('');
	$PayFlow->setCustomerPhone($phone);
	$PayFlow->setCustomerEmail($email);
	$PayFlow->setCustomField('ITEMNAME', 'Conf_special');
	$PayFlow->setPaymentComment('this is for test');

	if($PayFlow->processTransaction()):
	  echo('Transaction Processed Successfully!');
	else:
	  echo('Transaction could not be processed at this time.');
	endif;
	 
	echo('<h2>Name Value Pair String:</h2>');
	echo('<pre>');
	print_r($PayFlow->debugNVP('array'));
	echo('</pre>');
	 
	echo('<h2>Response From Paypal:</h2>');
	echo('<pre>');
	print_r($PayFlow->getResponse());
	echo('</pre>');
	 
	unset($PayFlow);
}